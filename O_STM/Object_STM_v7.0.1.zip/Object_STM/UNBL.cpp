/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   UNBL.cpp
 * Author: zoltan
 * 
 * Created on January 27, 2018, 9:41 PM
 */

#include "UNBL.h"

UNBL::UNBL(const UNBL& orig) {
}

UNBL::~UNBL() {
}

BANK* UNBL::getBaseCopy(OSTM* object)
{
    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new UNBL(objTO,object->Get_Version(),object->Get_Unique_ID()); 
    return obj;
}

void UNBL::copy(OSTM* to, OSTM* from){

	UNBL* objTO = dynamic_cast<UNBL*>(to);
	UNBL* objFROM = dynamic_cast<UNBL*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());
   
}

UNBL* UNBL::_cast(OSTM* _object){

    return static_cast<UNBL*>(_object);
}

void UNBL::toString()
{
   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
	 std::cout << "\nUNBL BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void UNBL::SetAddress(std::string address) {
    this->address = address;
}

std::string UNBL::GetAddress() const {
    return address;
}

void UNBL::SetBalance(double balance) {
    this->balance = balance;
}

double UNBL::GetBalance() const {
    return balance;
}

void UNBL::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int UNBL::GetAccountNumber() const {
    return accountNumber;
}

void UNBL::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string UNBL::GetLastName() const {
    return lastName;
}

void UNBL::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string UNBL::GetFirstName() const {
    return firstName;
}

void UNBL::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string UNBL::GetFullname() const {
    return fullname;
}

