#include "TM.h"
#include <thread>
#include <unistd.h>
#include <sys/types.h>
#include <iostream>

TM::TM()
{
    std::map<std::thread::id, TX>txMap;
//    pid_t ppid = getppid();
//	registerTX();
}

//TM::TM(int ppid)//pid_t l_ppid, std::thread::id l_id,std::shared_ptr<Tobj>obj)
//{
//   // std::map<pid_t, TX>txMap;
//   // pid_t ppid = getppid();
//	//registerTX();
//}

TM::~TM()
{

}

//TM Transaction managger checking the Process ID existence in the map
//If not in the map then register
void TM::registerTX()//,std::thread::id id,std::shared_ptr<Tobj>obj){
{
   // std::lock_guard<std::mutex> guard(register_Lock);
        //If Main process not registered then register 
       // std::cout << "register in TM " << std::endl;
    //pid_t ppid = getppid();
        std::map<std::thread::id, std::shared_ptr<TX>>::iterator it = txMap.find(std::this_thread::get_id());
        if(it == txMap.end())
        {
           // std::cout << "register in in TM " << std::endl;
            //TX tx;
            std::shared_ptr<TX> _transaction_object(new TX(std::this_thread::get_id()));
           // std::shared_ptr<Base> acc( new Base(10, 500, 10.10, "First"));
            //txMap[ppid] = TX();
            txMap.insert({std::this_thread::get_id(),_transaction_object});
            //working.insert({uniqueID,copyOfSharedPtr});
        }
        else
        {
            /*
             * Increase nesting level 
             */
            it->second->_increase_tx_nesting();
        }
}

void TM::_TX_EXIT(){
    TX tx(std::this_thread::get_id());
    tx.ostm_exit();
}

/*
 * It is automatic shouldn't need!!! ???
 */
//void TM::_clean_tx()
//{
//    //std::cout << "[REMOVE TRANSACTION OBJECT] " << std::endl;
//    std::lock_guard<std::mutex> guard(remove_Lock);
//    //pid_t ppid = getppid();
//    std::map<std::thread::id, std::shared_ptr<TX>>::iterator it = txMap.find(std::this_thread::get_id());
//    if(it != txMap.end())
//    {
//      // std::cout << "erase in TM " << std::endl;
//       std::map<std::thread::id, std::shared_ptr<TX>>::iterator it = txMap.find(std::this_thread::get_id());
//        if(it == txMap.end())
//        {
//            std::cout << "USELESS TX not in the map " << std::endl;
//        }
//        else
//        {
//            // std::cout << "NOT USELESS TX  in the map " << std::endl;
//            //delete it->second;
////            it->second = nullptr;
////            //it->second->ostm_exit();
////            txMap.erase(txMap.find(std::this_thread::get_id()));
//            // it->second->~TX();
//             txMap.erase(txMap.find(std::this_thread::get_id()));
//        }
//    }
//    else
//    {
//        std::cout << "Not erase in TM " << std::endl;
//    }
//    
//}


void TM::print_all(){
    get_Lock.lock();
    for (auto current = txMap.begin(); current != txMap.end(); ++current) {
        std::cout << "KEY : " << current->first << std::endl;
    }
    std::cout << "************************" << std::endl;
    get_Lock.unlock();
}
 
//ppid is a simple unsigned integer
std::shared_ptr<TX>const TM::_get_tx()//,std::thread::id l_id)
{
  //  std::cout << "Get transaction object " << std::endl;
    std::lock_guard<std::mutex> guard(get_Lock);
    //pid_t ppid = getppid();
    std::map<std::thread::id, std::shared_ptr<TX>>::iterator it = txMap.find(std::this_thread::get_id());
    if(it == txMap.end())
    {
     //  std::cout << "Missing TX redirect to create " << std::endl;
       registerTX();
      // getTransactionObject(ppid);
    }
    it = txMap.find(std::this_thread::get_id());
//    if(it != txMap.end())
//    {
//     //   std::cout << "Return TX object " << std::endl;
//        
//    }
    //auto& obj = it->second;
    return it->second;
    //return obj;
}

//bool TM::validTransaction()
//{
//    pid_t ppid = getppid();
//    std::map<pid_t, TX>::iterator it = txMap.find(ppid);
//    if(it != txMap.end())
//    {
//        return true;
//    }
//    else
//    {
//        return false;
//    }
//}
