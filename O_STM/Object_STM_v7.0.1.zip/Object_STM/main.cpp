/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   main.cpp
 * Author: zoltan
 *
 * Created on November 27, 2017, 9:26 PM
 */

#include <cstdlib>
#include <iostream>
#include <thread>
//#include <unistd.h>//used for pid_t

//STM library requirement
#include "TM.h"
#include "AIB.h"    //Bank Account
#include "BOI.h"    //Bank Account
#include "BOA.h"    //Bank Account
#include "SWBPLC.h" //Bank Account
#include "ULSTER.h" //Bank Account
#include "UNBL.h"
#include "WAREHOUSE.h"
#include "CARPHONE_WAREHOUSE.h"
#include "CARLOW_W.h"   //Bank Account
#include <mutex>
#include <memory>
#include <condition_variable>
#include <vector>

/******************************************************************************************************************************************
 *******************************************************   Object - STM : TEST   ********************************************************************
 ******************************************************************************************************************************************/

static int threadCounter = 0;
static int counter = 0;
static int vector_number = 100;

void _build_collections_();

void _six_account_transfer_(OSTM* _to_, OSTM* _from_one_, OSTM* _from_two_, OSTM* _from_three_, OSTM* _from_four_, OSTM* _from_five_, TM& _tm, double _amount) {
    std::shared_ptr<TX> tx = _tm._get_tx();
    /*
     * Register the two single account
     */
    tx->_register(_to_);
    tx->_register(_from_one_);
    tx->_register(_from_two_);
    tx->_register(_from_three_);
    tx->_register(_from_four_);
    tx->_register(_from_five_);
    
    /*
     * Required pointers to use in transaction
     */
    OSTM* _TO_OSTM; OSTM* _FROM_ONE_OSTM; OSTM* _FROM_TWO_OSTM; OSTM* _FROM_THREE_OSTM; OSTM* _FROM_FOUR_OSTM; OSTM* _FROM_FIVE_OSTM;
    BANK* _TO_; BANK* _FROM_ONE_; BANK* _FROM_TWO_; BANK* _FROM_THREE_; BANK* _FROM_FOUR_; BANK* _FROM_FIVE_;

    bool done = false;
    while (!done) {
        /*
         * From OSTM* to BANK* to access the virtual methods
         */
        _TO_ = dynamic_cast<BANK*>(tx->load(_to_));
        _FROM_ONE_ = dynamic_cast<BANK*>(tx->load(_from_one_));
        _FROM_TWO_ = dynamic_cast<BANK*>(tx->load(_from_two_));
        _FROM_THREE_ = dynamic_cast<BANK*>(tx->load(_from_three_));
        _FROM_FOUR_ = dynamic_cast<BANK*>(tx->load(_from_four_));
        _FROM_FIVE_ = dynamic_cast<BANK*>(tx->load(_from_five_));
        /*
         * Make changes with the objects
         */
        _TO_->SetBalance(_TO_->GetBalance() + (_amount * 5));
        _FROM_ONE_->SetBalance(_FROM_ONE_->GetBalance() - _amount);
        _FROM_TWO_->SetBalance(_FROM_TWO_->GetBalance() - _amount);
        _FROM_THREE_->SetBalance(_FROM_THREE_->GetBalance() - _amount);
        _FROM_FOUR_->SetBalance(_FROM_FOUR_->GetBalance() - _amount);
        _FROM_FIVE_->SetBalance(_FROM_FIVE_->GetBalance() - _amount);
        /*
         * From BANK* to OSTM* to store the memory spaces
         */
        _TO_OSTM = dynamic_cast<OSTM*>(_TO_);
        _FROM_ONE_OSTM = dynamic_cast<OSTM*>(_FROM_ONE_);
        _FROM_TWO_OSTM = dynamic_cast<OSTM*>(_FROM_TWO_);
        _FROM_THREE_OSTM = dynamic_cast<OSTM*>(_FROM_THREE_);
        _FROM_FOUR_OSTM = dynamic_cast<OSTM*>(_FROM_FOUR_);
        _FROM_FIVE_OSTM = dynamic_cast<OSTM*>(_FROM_FIVE_);
        /*
         * Store changes
         */
        tx->store(_TO_OSTM);
        tx->store(_FROM_ONE_OSTM);
        tx->store(_FROM_TWO_OSTM);
        tx->store(_FROM_THREE_OSTM);
        tx->store(_FROM_FOUR_OSTM);
        tx->store(_FROM_FIVE_OSTM);
        /*
         * Commit changes
         */
        done = tx->commit();
    }
    /*
     * Clean up pointers after thread
     */
    tx->th_exit();
    //_tm._clean_tx();

}

void _two_account_transfer_(OSTM* _to_, OSTM* _from_, TM& _tm, double _amount) {
    std::shared_ptr<TX> tx = _tm._get_tx();
    /*
     * Register the two single account
     */
    tx->_register(_to_);
    tx->_register(_from_);
    /*
     * Declare required pointers 
     */
    BANK* _TO_BANK_ ; BANK* _FROM_BANK_;
    OSTM* _TO_OSTM_; OSTM* _FROM_OSTM_;

    bool done = false;
    while (!done) {
        /*
         * From OSTM* to BANK* to access the virtual methods
         */
        _TO_BANK_ = dynamic_cast<BANK*>(tx->load(_to_));
        _FROM_BANK_ = dynamic_cast<BANK*>(tx->load(_from_));
        /*
         * Make changes with the objects
         */
        _TO_BANK_->SetBalance(_TO_BANK_->GetBalance() + _amount);
        _FROM_BANK_->SetBalance(_FROM_BANK_->GetBalance() - _amount);
        /*
         * From BANK* to OSTM* to store the memory spaces
         */
        _TO_OSTM_ = dynamic_cast<OSTM*>(_TO_BANK_);
        _FROM_OSTM_ = dynamic_cast<OSTM*>(_FROM_BANK_);
        /*
         * Store changes
         */
        tx->store(_TO_OSTM_);
        tx->store(_FROM_OSTM_);
        /*
         * Commit changes
         */
        done = tx->commit();
    }
    /*
     * Clean up pointers after thread
     */
    tx->th_exit();
//    _tm.print_all();
 //   _tm._clean_tx();
//    _tm.print_all();
}

void _complex_transfer_(OSTM* _from_, OSTM* _from_two_, std::vector<OSTM*> _customer_vec, TM& _tm, double _amount) {
    std::shared_ptr<TX> tx = _tm._get_tx();
    /*
     * Register the two single account
     */
    tx->_register(_from_);
    tx->_register(_from_two_);
    /*
     * Declare required pointers 
     */
    OSTM* _FROM_OSTM_ONE_; OSTM* _FROM_OSTM_TWO_; OSTM* _TO_OSTM_;
    BANK* _FROM_; BANK* _FROM_TWO_; BANK* _TO_;

    bool done = false;
    while (!done) {
        for (int i = 0; i < vector_number; ++i) {
            /*
             * Register customers accounts from the collection (vector) 
             */
            tx->_register(_customer_vec[i]);
            /*
             * From OSTM* to BANK* to access the virtual methods
             */
            _FROM_     = dynamic_cast<BANK*>(tx->load(_from_));
            _FROM_TWO_ = dynamic_cast<BANK*>(tx->load(_from_two_));
            _TO_       = dynamic_cast<BANK*>(tx->load(_customer_vec[i]));
            /*
             * Make changes with the objects
             */
            _FROM_->SetBalance(_FROM_->GetBalance() - _amount);
            _FROM_TWO_->SetBalance(_FROM_TWO_->GetBalance() - _amount);
            _TO_->SetBalance(_TO_->GetBalance() + (_amount * 2));
            /*
             * From BANK* to OSTM* to store the memory spaces
             */
            _FROM_OSTM_ONE_  = dynamic_cast<OSTM*>(_FROM_);
            _FROM_OSTM_TWO_  = dynamic_cast<OSTM*>(_FROM_TWO_);
            _TO_OSTM_        = dynamic_cast<OSTM*>(_TO_);
            /*
             * Store changes
             */
            tx->store(_FROM_OSTM_ONE_);
            tx->store(_FROM_OSTM_TWO_);
            tx->store(_TO_OSTM_);
        }
        /*
         * Commit changes
         */
        done = tx->commit();
   }
    /*
     * Clean up pointers after thread
     */
    tx->th_exit();
//    _tm.print_all();
  //  _tm._clean_tx();
//    _tm.print_all();
    
}

void _phone_transfer_(OSTM* _to_, OSTM* _from_, TM& _tm, double _amount) {
    std::shared_ptr<TX> tx = _tm._get_tx();
    /*
     * Register the two single account
     */
    tx->_register(_to_);
    tx->_register(_from_);
    /*
     * Declare required pointers 
     */
    WAREHOUSE* _TO_SHOP_ ; WAREHOUSE* _FROM_DIST_;
    OSTM* _TO_OSTM_; OSTM* _FROM_OSTM_;

    bool done = false;
    while (!done) {
        /*
         * From OSTM* to BANK* to access the virtual methods
         */
        _TO_SHOP_ = dynamic_cast<WAREHOUSE*>(tx->load(_to_));
        _FROM_DIST_ = dynamic_cast<WAREHOUSE*>(tx->load(_from_));
        /*
         * Make changes with the objects
         */
        _TO_SHOP_->SetNumber_of_nokia(_TO_SHOP_->GetNumber_of_nokia() + _amount);
        _FROM_DIST_->SetNumber_of_nokia(_FROM_DIST_->GetNumber_of_nokia() - _amount);
        
        _TO_SHOP_->SetNumber_of_samsung(_TO_SHOP_->GetNumber_of_samsung() + _amount);
        _FROM_DIST_->SetNumber_of_samsung(_FROM_DIST_->GetNumber_of_samsung() - _amount);
        
        _TO_SHOP_->SetNumber_of_iphones(_TO_SHOP_->GetNumber_of_iphones() + _amount);
        _FROM_DIST_->SetNumber_of_iphones(_FROM_DIST_->GetNumber_of_iphones() - _amount);
        
        _TO_SHOP_->SetNumber_of_sony(_TO_SHOP_->GetNumber_of_sony() + _amount);
        _FROM_DIST_->SetNumber_of_sony(_FROM_DIST_->GetNumber_of_sony() - _amount);
        /*
         * From BANK* to OSTM* to store the memory spaces
         */
        _TO_OSTM_ = dynamic_cast<OSTM*>(_TO_SHOP_);
        _FROM_OSTM_ = dynamic_cast<OSTM*>(_FROM_DIST_);
        /*
         * Store changes
         */
        tx->store(_TO_OSTM_);
        tx->store(_FROM_OSTM_);
        /*
         * Commit changes
         */
        done = tx->commit();
    }
    /*
     * Clean up pointers after thread
     */
    tx->th_exit();
//    _tm.print_all();
//    _tm._clean_tx();
//    _tm.print_all();
  
}

int main(void) {

    TM tm;
    
    /* SIX OSTM* VECTOR ARRAY */
    std::vector<OSTM*> _customer_vec(vector_number);
    std::vector<OSTM*> _warehouse_vec(vector_number);

    /*SIX SINGLE OSTM* BANK CUSTOMERS*/ 
    OSTM* aib_ptr    = new AIB(100, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    OSTM* boi_ptr    = new BOI(200, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    OSTM* boa_ptr    = new BOA(300, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    OSTM* swplc_ptr  = new SWBPLC(400, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    OSTM* ulster_ptr = new ULSTER(500, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    OSTM* unbl_ptr   = new UNBL(600, 500, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
    
    OSTM* w_dist = new CARPHONE_WAREHOUSE();
    OSTM* c_shop = new CARLOW_W();
    
//    w_dist->toString();
//    c_shop->toString();
    aib_ptr->toString();
    boi_ptr->toString();
//    boa_ptr->toString();
//    swplc_ptr->toString();
//    ulster_ptr->toString();
//    unbl_ptr->toString();
    
    for(int i=0;i<vector_number;++i){
        if(i%6 == 0){
             _customer_vec[i] = new AIB(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
        else if(i%5 == 0){
             _customer_vec[i] = new BOI(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
        else if(i%4 == 0){
             _customer_vec[i] = new BOA(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
        else if(i%3 == 0){
             _customer_vec[i] = new SWBPLC(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
        else if(i%2 == 0){
             _customer_vec[i] = new ULSTER(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
        else if(i%1 == 0){
             _customer_vec[i] = new UNBL(i, 50, "Zoltan", "Fuzesi", "Ballynasillogue, Borris, Co.Carlow");
        }
    }
    
    
    int transferAmount = 1;
    int threadArraySize = 30;
    std::thread thArray[threadArraySize];
    /*
     * Creating threads^n -> threadArraySize
     */

    for (int i = 0; i < threadArraySize; ++i) {

        
            //thArray[i] = std::thread(_two_account_transfer_, aib_ptr, boi_ptr, std::ref(tm), transferAmount);
            
//    if (i % 3 == 0) 
//        thArray[i] = std::thread(_phone_transfer_, c_shop, w_dist, std::ref(tm), transferAmount);
//        //thArray[i] = std::thread(_two_account_transfer_, aib_ptr, boi_ptr, std::ref(tm), transferAmount);
//    else if (i % 2 == 0)
//        thArray[i] = std::thread(_six_account_transfer_, boi_ptr, boa_ptr, swplc_ptr, ulster_ptr, aib_ptr, unbl_ptr, std::ref(tm), transferAmount);
//        //thArray[i] = std::thread(_two_account_transfer_, boa_ptr, swplc_ptr, std::ref(tm), transferAmount);
//    else if (i % 1 == 0)
//        thArray[i] = std::thread(_complex_transfer_, aib_ptr, boi_ptr, std::ref(_customer_vec), std::ref(tm), transferAmount);
//        //thArray[i] = std::thread(_two_account_transfer_, ulster_ptr, unbl_ptr, std::ref(tm), transferAmount);
       
     
    if (i % 3 == 0) 
       //thArray[i] = std::thread(_complex_transfer_,  boi_ptr, aib_ptr, std::ref(_customer_vec), std::ref(tm), transferAmount);
              // thArray[i] = std::thread(_phone_transfer_, c_shop, w_dist, std::ref(tm), transferAmount);
        thArray[i] = std::thread(_two_account_transfer_, aib_ptr, boi_ptr, std::ref(tm), transferAmount);
    else if (i % 2 == 0)
        //thArray[i] = std::thread(_complex_transfer_, aib_ptr, boi_ptr, std::ref(_customer_vec), std::ref(tm), transferAmount);
        //thArray[i] = std::thread(_six_account_transfer_, boi_ptr, boa_ptr, swplc_ptr, ulster_ptr, aib_ptr, unbl_ptr, std::ref(tm), transferAmount);
       // thArray[i] = std::thread(_two_account_transfer_, boa_ptr, swplc_ptr, std::ref(tm), transferAmount);
        thArray[i] = std::thread(_two_account_transfer_, aib_ptr,  boi_ptr, std::ref(tm), transferAmount);
    else if (i % 1 == 0)
        thArray[i] = std::thread(_complex_transfer_, aib_ptr, boi_ptr, std::ref(_customer_vec), std::ref(tm), transferAmount);
       // thArray[i] = std::thread(_two_account_transfer_, ulster_ptr, unbl_ptr, std::ref(tm), transferAmount);
        //thArray[i] = std::thread(_two_account_transfer_, aib_ptr, boi_ptr, std::ref(tm), transferAmount);


    }
    /*
     * Join threads^n -> threadArraySize
     */
    for (int i = 0; i < threadArraySize; ++i) {
        thArray[i].join();
    }

//    for(int i=0; i<600; ++i){
//        _customer_vec[i]->toString();
//    }
    std::cout << "\nMain process print " << std::endl;
    
    aib_ptr->toString();
    boi_ptr->toString();
//    boa_ptr->toString();
//    swplc_ptr->toString();
//    ulster_ptr->toString();
//    unbl_ptr->toString();
//    
//    w_dist->toString();
//    c_shop->toString();
    
    std::cout << "\nMAIN PROCESS EXIT !!!! " << std::endl;
    std::shared_ptr<TX> tx = tm._get_tx();
    int t = tx->getTest_counter();
    std::cout << "Rollback counter is : " << t << std::endl;
    //_customer_vec[555]->toString();
    tm._TX_EXIT();
    return 0;
}

/******************************************************************************************************************************************
 *******************************************************Object STM TEST : FINISH ******************************************************************
 ******************************************************************************************************************************************/

/*
 * BOA  - Bank of America
 * Ulster - Ulster Bank
 * UNBL - united National Bank limited
 * TSB - bank
 * TPFLC - Tesco Personal Finance PLC
 * SBOI - State Bank of India
 * SBL - Staling Bank limited
 * SWBPLC - Scottish Windows Bank PLc
 * AIB - Allied Irish Bank
 * BOI - Bank of Ireland
 */


//    std::string nameArray[] = {"Abigail", "Alaina", "Albina", "Celia", "Esty", "Cheryl", "Eudora", "Chloe", "Cecilia", "Erika", "Eva", "Flora", "Dana", "Diana", "Gwendolyn", "Hannah", "Harriet", "Dawn", "Audrey", "Aviva", "Angela", "Glenda", "Gemma", "Colette", "Daisy", "Gabriel", "Bertha", "Brenda", "Eileen", "Carolyn", "Ellen", "Isla", "Candy", "Edith", "Dulice", "Betty", "Helena", "Jana", "Liza", "Priscilla", "Rhonda", "Margaret", "Joella", "Lorna", "Jenna", "Jodie", "Maggie", "Margaret", "Mariah", "Patsy", "Jemina", "Matilda", "Morgan", "Kaylee", "Megan", "Salma", "Samantha", "Sarah", "Sheryl", "Katey", "Michelle", "Laura", "Nancy", "Tamara", "Leila", "Kim", "Suzanne", "Olivia", "Valerie", "Lily", "vanessa", "Wanda", "Yasmine", "Yvonne", "Zelda", "Wendy", "Whithney", "Winnie", "Viola", "Virginia", "Vilma", "Winifried", "Jerry", "Jessie", "Lucinda", "Patty", "Opal", "Clarissa", "Cleo", "April", "Aubrey", "Danna", "Gwyneth", "Arabella", "Beatrice", "Destiny", "Dede", "Hero", "Gretrude", "Avis", "Dorina"};
//    std::string surenames[] = {"Abraham", "Acton", "Addington", "Adley", "Ainsley", "Alby", "Allerton", "Alton", "Anderton", "Ansley", "Fawcett", "Fulton", "Garfield", "Garrick", "Gladstone", "Graham", "Gresham", "Hackney", "Haddlee", "Hadleigh", "Ashley", "Ashton", "Axton", "Hailey", "Hale", "Haley", "Hamilton", "Hampton", "Harlan", "Harley", "Hartford", "Hastings", "hayden", "Hayley", "Holton", "Home", "Hornsby", "Huxley", "Blankley", "Blyth", "Bradford", "Bradley", "Brandy", "brandon", "Branson", "Bristol", "Brixton", "Browing", "Budd", "Burton", "Byron", "Kelsey", "Kendal", "Kent", "Kimberly", "Kinsley", "Kirby", "Lanchaster", "Landon", "Langley", "Law", "Lester", "Lincoln", "lindsay", "Marlee", "Marley", "Marlowe", "Marston", "Clapham", "Clare", "Clayden", "Clayton", "Clifford", "Clifton", "Clive", "Colton", "Colby", "Cotton", "Crawford", "Cromwell", "Middleton", "Milton", "Mitchell", "Morton", "Nash", "Nibley", "Norton", "Oakes", "Oakley", "Paxton", "Payton", "Perry", "Peyton", "Dalton", "Darby", "Darlington", "Davenport", "Dayton", "Pinkerton", "Prescott"};
//    std::string streets[] = {"High street", "Station road", "Main street", "Park road", "Crunch street", "Church street", "London road", "Victoria road", "Green lane", "Manor road", "Church lane", "Park evenue", "The evenue", "Queens road", "New road", "Grange road", "Kings road", "Kingsway", "Windsor road", "Highfield road", "Mill lane", "Alexander road", "York road", "Main road", "Broadway", "King street", "George street", "Victori street", "Albert road", "West road"};
//    std::string count[] = {"Antrim", "Armagh", "Carlow", "Cavan", "Clare", "Cork", "Derry", "Donegal", "Down", "Dublin", "Fermanagh", "Galway", "Kerry", "Kildare", "Kilkenny", "Laois", "Leitrim", "limerick", "Longford", "Louth", "Mayo", "Meath", "monaghan", "offlay", "Roscommon", "Sligo", "Tipperary", "Tyrone", "Waterford", "Westmeath"};

//    if (i % 3 == 0) 
//        thArray[i] = std::thread(_complex_transfer_, aib_ptr, boi_ptr, std::ref(_customer_vec), std::ref(tm), transferAmount);
//    else if (i % 2 == 0)            
//        thArray[i] = std::thread(_two_account_transfer_, aib_ptr, boi_ptr, std::ref(tm), transferAmount);
//    else if (i % 1 == 0)
//        thArray[i] = std::thread(_six_account_transfer_, boi_ptr, boa_ptr, swplc_ptr, ulster_ptr, aib_ptr, unbl_ptr, std::ref(tm), transferAmount);
//       
//        
//        if (i % 3 == 0) {
//            thArray[i] = std::thread(_transfer_aib_boi_account, std::ref(_aibcustomer_vec), std::ref(aib), std::ref(boi), std::ref(tm), transferAmount);
//            //thArray[i] = std::thread(_transfer_aib_boi_boa_swplc_ulster_unbl_account, std::ref(aib), std::ref(boi), std::ref(boa), std::ref(swplc), std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//        } else if (i % 2 == 0) {
//            //thArray[i] = std::thread(_transfer_aib_boi_swplc_ulster_account, std::ref(aib), std::ref(boi), std::ref(boa), std::ref(swplc), std::ref(ulster), std::ref(tm), transferAmount);
//            thArray[i] = std::thread(_transfer_ulster_unbl_account, std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//        } else if (i % 1 == 0) {
//            
//             //thArray[i] = std::thread(_transfer_any, std::ref(aibCustomers), std::ref(boiCustomers), std::ref(boaCustomers), std::ref(swbplcCustomers), std::ref(ulsterCustomers), std::ref(unblCustomers), std::ref(tm), transferAmount);
//            thArray[i] = std::thread(_transfer_any, std::ref(_aibcustomer_vec), std::ref(_boi_customers_vec), std::ref(_boa_customers_vec), std::ref(_swbplc_customers_vec), std::ref(_ulster_customers_vec), std::ref(_unbl_customers_vec), std::ref(aib), std::ref(tm), transferAmount);
//        }

//        if (i % 3 == 0) {
//            thArray[i] = std::thread(_transfer_ulster_unbl_account, std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//            //thArray[i] = std::thread(_transfer_aib_boi_boa_swplc_ulster_unbl_account, std::ref(aib), std::ref(boi), std::ref(boa), std::ref(swplc), std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//        } else if (i % 2 == 0) {
//            //thArray[i] = std::thread(_transfer_aib_boi_swplc_ulster_account, std::ref(aib), std::ref(boi), std::ref(boa), std::ref(swplc), std::ref(ulster), std::ref(tm), transferAmount);
//            thArray[i] = std::thread(_transfer_ulster_unbl_account, std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//        } else if (i % 1 == 0) {
//            
//             //thArray[i] = std::thread(_transfer_any, std::ref(aibCustomers), std::ref(boiCustomers), std::ref(boaCustomers), std::ref(swbplcCustomers), std::ref(ulsterCustomers), std::ref(unblCustomers), std::ref(tm), transferAmount);
//            thArray[i] = std::thread(_transfer_ulster_unbl_account, std::ref(ulster), std::ref(unbl), std::ref(tm), transferAmount);
//        }
        
         
         //thArray[i] = std::thread(_transfer_arr, std::ref(aibCustomers), std::ref(tm), transferAmount);
        
        //thArray[i] = std::thread(_transfer_any_collection, std::ref(_aibcustomer_vec), std::ref(tm), transferAmount);