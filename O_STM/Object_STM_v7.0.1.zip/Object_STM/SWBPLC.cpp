/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   SWBPLC.cpp
 * Author: zoltan
 * 
 * Created on January 27, 2018, 9:42 PM
 */

#include "SWBPLC.h"

SWBPLC::SWBPLC(const SWBPLC& orig) {
}

SWBPLC::~SWBPLC() {
}


BANK* SWBPLC::getBaseCopy(OSTM* object)
{
    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new SWBPLC(objTO,object->Get_Version(),object->Get_Unique_ID()); 
    return obj;
}

void SWBPLC::copy(OSTM* to, OSTM* from){

	SWBPLC* objTO = dynamic_cast<SWBPLC*>(to);
	SWBPLC* objFROM = dynamic_cast<SWBPLC*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());

    
}

SWBPLC* SWBPLC::_cast(OSTM* _object){

    return static_cast<SWBPLC*>(_object);
}

void SWBPLC::toString()
{
   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
	 std::cout << "\nSWBPLC BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void SWBPLC::SetAddress(std::string address) {
    this->address = address;
}

std::string SWBPLC::GetAddress() const {
    return address;
}

void SWBPLC::SetBalance(double balance) {
    this->balance = balance;
}

double SWBPLC::GetBalance() const {
    return balance;
}

void SWBPLC::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int SWBPLC::GetAccountNumber() const {
    return accountNumber;
}

void SWBPLC::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string SWBPLC::GetLastName() const {
    return lastName;
}

void SWBPLC::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string SWBPLC::GetFirstName() const {
    return firstName;
}

void SWBPLC::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string SWBPLC::GetFullname() const {
    return fullname;
}

