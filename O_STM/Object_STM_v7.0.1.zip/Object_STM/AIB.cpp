/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AIB.cpp
 * Author: zoltan
 * 
 * Created on January 17, 2018, 8:02 PM
 */

#include <math.h>

#include "AIB.h"


AIB::AIB(const AIB& orig) {
}

AIB::~AIB() {
}

BANK* AIB::getBaseCopy(OSTM* object)
{

    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new AIB(objTO, object->Get_Version(),object->Get_Unique_ID());
    return obj;
}

void AIB::copy(OSTM* to, OSTM* from){

    AIB* objTO = dynamic_cast<AIB*>(to);
    AIB* objFROM = dynamic_cast<AIB*>(from);
    objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
    objTO->Set_Version(objFROM->Get_Version());
    objTO->SetAccountNumber(objFROM->GetAccountNumber());
    objTO->SetBalance(objFROM->GetBalance());
}

AIB* AIB::_cast(OSTM* _object){
    
    return static_cast<AIB*>(_object);
}

/*
 * To string void display object values
 */
void AIB::toString()
{
   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
     std::cout << "\nAIB BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}




void AIB::SetAddress(std::string address) {
    this->address = address;
}

std::string AIB::GetAddress() const {
    return address;
}

void AIB::SetBalance(double balance) {
    this->balance = balance;
}

double AIB::GetBalance() const {
    return balance;
}

void AIB::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int AIB::GetAccountNumber() const {
    return accountNumber;
}

void AIB::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string AIB::GetLastName() const {
    return lastName;
}

void AIB::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string AIB::GetFirstName() const {
    return firstName;
}

void AIB::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string AIB::GetFullname() const {
    return fullname;
}


///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
///* 
// * File:   AIB.cpp
// * Author: zoltan
// * 
// * Created on January 17, 2018, 8:02 PM
// */
//
//#include <math.h>
//
//#include "AIB.h"
//
//
//AIB::AIB(const AIB& orig) {
//}
//
//AIB::~AIB() {
//}
//
//
//AIB* AIB::getBaseCopy(OSTM& object)
//{
//   // std::cout << "[AIB GETBASECOPY &]" << std::endl;
//    AIB* obj =  new AIB(object,object.Get_Version(),object.Get_Unique_ID()); 
//    return obj;
//}
//
//AIB* AIB::getBaseCopy(OSTM* object)
//{
//    //std::cout << "[AIB GETBASECOPY *]" << std::endl;
//    AIB* obj =  new AIB(object,object->Get_Version(),object->Get_Unique_ID()); 
//    return obj;
//}
//
//void AIB::copy(OSTM* to, OSTM* from){
//   // std::cout <<"AIB copying " << std::endl;
//    AIB* objTO = dynamic_cast<AIB*>(to);
//    AIB* objFROM = dynamic_cast<AIB*>(from);
//    objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
//    objTO->Set_Version(objFROM->Get_Version());
//    objTO->SetAccountNumber(objFROM->GetAccountNumber());
//    objTO->SetBalance(objFROM->GetBalance());
//
//}
//
////AIB* AIB::_get_class(OSTM* object){
////    return static_cast<AIB*>(_object); 
////}
//
////bool AIB::get(OSTM* object){
////    if (dynamic_cast<AIB*>(object))
////        return true;
////    else
////        return false;
////}
//
//AIB* AIB::_cast(OSTM* _object){
//   // std::cout << "AIB casting" << std::endl;
//    return static_cast<AIB*>(_object);
//}
//
////std::string AIB::get_class(){
////    return "AIB";
////}
///*
// * To string void display object values
// */
//void AIB::toString()
//{
//   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
//     std::cout << "\nAIB BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
//}
//
////FACTORY METHODS ******************************************
//int AIB::_get_int_factory(std::string _function_){
//    
//}
//
//void AIB::_set_int_factory(std::string _function_, int value){
//    
//}
//    
//double AIB::_get_double_factory(std::string _function_){
//    if(!_function_.compare("getbalance")){
//        return GetBalance();
//    }
//    else if(!_function_.compare("somethingelse1")){
//        
//    }
//    else if(!_function_.compare("somethingelse2")){
//        
//    }
//}
//
//void AIB::_set_double_factory(std::string _function_, double value){
//    if(!_function_.compare("getbalance")){
//        SetBalance(value);
//    }
//}
//    
//bool AIB::_get_bool_factory(std::string _function_){
//
//}
//
//void AIB::_set_bool_factory(std::string _function_, bool value){
//    
//}
//    
//float AIB::_get_float_factory(std::string _function_){
//    
//}
//
//void AIB::_set_float_factory(std::string _function_, float value){
//    
//}
//
//std::string AIB::_get_string_factory(std::string _function_){
//    if(!_function_.compare("firstname")){
//        return GetFirstName();
//    }
//    else if(!_function_.compare("lastname")){
//        return GetLastName();
//    }
//    else if(!_function_.compare("address")){
//        return GetAddress();
//    }
//    else if(!_function_.compare("fullname")){
//        return GetFullname();
//    }
//}
//
//void AIB::_set_string_factory(std::string _function_, std::string value){
//    
//}
//    
//char AIB::_get_char_factory(std::string _function_){
//    
//}
//    
//char AIB::_set_char_factory(std::string _function_, char value){
//    
//}
//
////FACTORY METHODS ******************************************
//
//
//
//void AIB::SetAddress(std::string address) {
//    this->address = address;
//}
//
//std::string AIB::GetAddress() const {
//    return address;
//}
//
//void AIB::SetBalance(double balance) {
//    this->balance = balance;
//}
//
//double AIB::GetBalance() const {
//    return balance;
//}
//
//void AIB::SetAccountNumber(int accountNumber) {
//    this->accountNumber = accountNumber;
//}
//
//int AIB::GetAccountNumber() const {
//    return accountNumber;
//}
//
//void AIB::SetLastName(std::string lastName) {
//    this->lastName = lastName;
//}
//
//std::string AIB::GetLastName() const {
//    return lastName;
//}
//
//void AIB::SetFirstName(std::string firstName) {
//    this->firstName = firstName;
//}
//
//std::string AIB::GetFirstName() const {
//    return firstName;
//}
//
//void AIB::SetFullname(std::string fullname) {
//    this->fullname = fullname;
//}
//
//std::string AIB::GetFullname() const {
//    return fullname;
//}
//
