
#include "TX.h"
#include <iostream>

std::map<int, OSTM* >TX::main_Process_Map_collection;

std::mutex TX::register_Lock;

std::mutex TX::_commit_Lock;
int TX::test_counter = 0;

TX::TX(std::thread::id id) {
    this->transaction_Number = id;
    this->_tx_nesting_level = 0;
}

TX::~TX() {
    // std::cout << "TX deconstructor clear elements " << std::endl;
}

TX::TX(const TX& orig) {

}

void TX::_increase_tx_nesting() {
    _tx_nesting_level -= 1;
}

void TX::_decrease_tx_nesting() {
    _tx_nesting_level += 1;
}

int TX::getTest_counter() {
    return TX::test_counter;
}


/*!
 * Clean up all associated values by the thread delete from working_Map_collection map
 */
void TX::th_exit() {
    //  std::map< std::thread::id, std::map< int, OSTM* > >::iterator working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(std::this_thread::get_id());
    if (_tx_nesting_level > 0) {
        /*
         * Active nested transactions running in background, do not delete anything yet
         */
    } else {
        /* 
         * Remove all elements (POINTERS) from transaction
         */
        for (auto current = working_Map_collection.begin(); current != working_Map_collection.end(); ++current) {
            if (current->second)
                delete (*current).second;
        }
        working_Map_collection.clear();

        for (auto current = rollback_Map_collection.begin(); current != rollback_Map_collection.end(); ++current) {
            if (current->second)
                delete (*current).second;
        }
        rollback_Map_collection.clear();

    }
}

/*!
 * DO NOT CALL THIS METHOD EXPLICITLY!!!!!!
 */
void TX::ostm_exit() {

    for (auto current = main_Process_Map_collection.begin(); current != main_Process_Map_collection.end(); ++current) {
        if (current->second)
            delete (*current).second;
    }
    main_Process_Map_collection.clear();

}

const std::thread::id TX::_get_tx_number() const {
    return transaction_Number;
}

void TX::_register(OSTM* object) {

   // std::lock_guard<std::mutex> guard(TX::register_Lock);

    while(!object->is_Locked());

    std::map<int, OSTM*>::iterator main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find(object->Get_Unique_ID());
    if (main_Process_Map_collection_Iterator == TX::main_Process_Map_collection.end()) {

        TX::main_Process_Map_collection.insert({object->Get_Unique_ID(), object});
    }

    std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object->Get_Unique_ID());
    if (working_Map_collection_Object_Shared_Pointer_Iterator == working_Map_collection.end()) {

        rollback_Map_collection.insert({object->Get_Unique_ID(), object->getBaseCopy(object)});
        working_Map_collection.insert({object->Get_Unique_ID(), object->getBaseCopy(object)});
    }
    
    object->unlock_Mutex();
}

OSTM* TX::load(OSTM* object) {

    std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;

    working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object->Get_Unique_ID());
    if (working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end()) {

        return working_Map_collection_Object_Shared_Pointer_Iterator->second->getBaseCopy(working_Map_collection_Object_Shared_Pointer_Iterator->second);
    }else {
        std::cout << "[ERROR LOAD]" << std::endl;
    }
}

void TX::store(OSTM* object) {

    std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;

    working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object->Get_Unique_ID());
    if (working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end()) {

        working_Map_collection_Object_Shared_Pointer_Iterator->second = object;

    } else {
        std::cout << "[ERROR STORE]" << std::endl;
    }
}

bool TX::commit() {
    
    //std::lock_guard<std::mutex> guard(TX::_commit_Lock);

    bool can_Commit = true;

    std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;

    std::map<int, OSTM*>::iterator main_Process_Map_collection_Iterator;
    for (working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.begin(); working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end(); working_Map_collection_Object_Shared_Pointer_Iterator++) {

        main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find(working_Map_collection_Object_Shared_Pointer_Iterator->second->Get_Unique_ID());
        /*
         * Busy wait WHILE object locked by other thread
         */
        while(!(main_Process_Map_collection_Iterator->second)->is_Locked());
        //(main_Process_Map_collection_Iterator)->second->lock_Mutex();
        
        if (main_Process_Map_collection_Iterator->second->Get_Version() > working_Map_collection_Object_Shared_Pointer_Iterator->second->Get_Version()) {

            working_Map_collection_Object_Shared_Pointer_Iterator->second->Set_Can_Commit(false);
            can_Commit = false;
            break;
        } else {

            working_Map_collection_Object_Shared_Pointer_Iterator->second->Set_Can_Commit(true);
        }
    }

    if (!can_Commit) {
        TX::test_counter += 1;

        for (working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.begin(); working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end(); working_Map_collection_Object_Shared_Pointer_Iterator++) {
          
            main_Process_Map_collection_Iterator  = TX::main_Process_Map_collection.find(working_Map_collection_Object_Shared_Pointer_Iterator->second->Get_Unique_ID());
            (working_Map_collection_Object_Shared_Pointer_Iterator->second)->copy(working_Map_collection_Object_Shared_Pointer_Iterator->second, main_Process_Map_collection_Iterator->second);

        }
        
        _release_object_lock();

        return false;
    } else {
        /*
         * Commit changes
         */
        
        for (working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.begin(); working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end(); working_Map_collection_Object_Shared_Pointer_Iterator++) {
            bool found = false;
            while (!found) {
                main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find((working_Map_collection_Object_Shared_Pointer_Iterator->second)->Get_Unique_ID());
                if (main_Process_Map_collection_Iterator != TX::main_Process_Map_collection.end()) {

                    (main_Process_Map_collection_Iterator->second)->copy(main_Process_Map_collection_Iterator->second, working_Map_collection_Object_Shared_Pointer_Iterator->second);
                    main_Process_Map_collection_Iterator->second->increase_VersionNumber();
                    found = true;
                } else {
                    std::cout << "[COMMIT ERROR]" << std::endl;
                    found = false;

                }
            }
        }

        _release_object_lock();

        return true;
    }
}//Commit finish

void TX::_release_object_lock(){
    
    std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;
    std::map<int, OSTM*>::iterator main_Process_Map_collection_Iterator;
    for (working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.begin(); working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end(); working_Map_collection_Object_Shared_Pointer_Iterator++) {

            main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find((working_Map_collection_Object_Shared_Pointer_Iterator->second)->Get_Unique_ID());
            if (main_Process_Map_collection_Iterator != TX::main_Process_Map_collection.end()) {
                /*
                 * Release object lock
                 */
                (main_Process_Map_collection_Iterator)->second->unlock_Mutex();
                
            } 
        }
}