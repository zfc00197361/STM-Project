/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   OSTM.h
 * Author: zoltan
 *
 * Created on December 18, 2017, 2:09 PM
 */

#ifndef OSTM_H
#define OSTM_H
#include <mutex>
#include <memory>
#include <string>
#include <iostream>
#include <string>

class OSTM {
public:
    OSTM();
    OSTM(int _version_number_, int _unique_id_);
   // OSTM(const OSTM& orig);
   // OSTM operator=(const OSTM& orig){};
    virtual ~OSTM();
    
    /*
     * OSTM REQUIRED VIRTUAL METHODS
     */ 
    virtual void copy(OSTM* from, OSTM* to){};
    
    virtual OSTM* _cast(OSTM* _object){};
    
    virtual OSTM* getBaseCopy(OSTM* object){std::cout << "[OSTM GETBASECOPY]" << std::endl;};
    
    virtual void toString(){};
    
    /*
     * OSTM METHODS
     */
    void Set_Unique_ID(int uniqueID);
    int Get_Unique_ID() const;
    void Set_Version(int version);
    int Get_Version() const;
    void increase_VersionNumber();
    bool Is_Can_Commit() const;
    void Set_Can_Commit(bool canCommit);
    void Set_Abort_Transaction(bool abortTransaction);
    bool Is_Abort_Transaction() const;
    void lock_Mutex();
    void unlock_Mutex();
    bool is_Locked();

private:
    /*
     * Object version number
     */
    int version;
    /*
     * Object unique identifier
     */
    int uniqueID;
    /*
     * Boolean value to check any other thread failed to commit
     */
    bool canCommit;
    /*
     * Abort the transaction
     */
    bool abort_Transaction;
    
    static int global_Unique_ID_Number;
    
    const int ZERO = 0;
    
    std::mutex mutex;

};

#endif /* OSTM_H */

    //std::unique_lock<std::mutex> lockGuard();
   // virtual std::string get_class(){};
    
//    virtual OSTM* _get_class(OSTM* object){};

    