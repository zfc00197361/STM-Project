/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   OSTM.cpp
 * Author: zoltan
 * 
 * Created on December 18, 2017, 2:09 PM
 */

#include "OSTM.h"

int OSTM::global_Unique_ID_Number = 0;
/*
 * Default constructor
 */
OSTM::OSTM()
{
    //std::cout << "OSTM CONSTRUCTOR" << global_Unique_ID_Number << std::endl;
    this->version = ZERO;
    this->uniqueID = ++global_Unique_ID_Number;
    this->canCommit = true;
    this->abort_Transaction = false;
}

/*
 * Custom Constructor Used for copy object
 */
OSTM::OSTM(int _version_number_, int _unique_id_)
{
   // std::cout << "OSTM COPY CONSTRUCTOR" << global_Unique_ID_Number << std::endl;
    this->uniqueID = _unique_id_;
    this->version = _version_number_;
    this->canCommit = true;
    this->abort_Transaction = false;
}

/*
 * De-constructor
 */
OSTM::~OSTM() {
    
    //std::cout << "OSTM DECONSTRUCTOR" << this->global_Unique_ID_Number << std::endl;
   // --global_Unique_ID_Number;
}

//std::unique_lock<std::mutex> OSTM::lockGuard() {
//    return std::unique_lock<std::mutex>(mutex);
//}

/*
 * Default Getters and Setters
 */
void OSTM::Set_Unique_ID(int uniqueID) {
    this->uniqueID = uniqueID;
}

int OSTM::Get_Unique_ID() const
{
    return uniqueID;
}

void OSTM::Set_Version(int version)
{
    this->version = version;
}

int OSTM::Get_Version() const
{
    return version;
}

void OSTM::increase_VersionNumber()
{
    this->version += 1;
}

void OSTM::Set_Can_Commit(bool canCommit) {
    this->canCommit = canCommit;
}

void OSTM::Set_Abort_Transaction(bool abortTransaction) {
    this->abort_Transaction = abortTransaction;
}

bool OSTM::Is_Abort_Transaction() const {
    return abort_Transaction;
}

void OSTM::lock_Mutex() {
    this->mutex.lock();
}

void OSTM::unlock_Mutex() {
    this->mutex.unlock();
}

bool OSTM::is_Locked(){
    return this->mutex.try_lock();
}
bool OSTM::Is_Can_Commit() const {
    return canCommit;
}


