#ifndef TX_H
#define TX_H
#include <cstdlib>
//#include <thread>
//#include <unistd.h>//used for pid_t
#include <utility>
#include <map>
#include <iostream>
//#include <atomic>
#include <mutex>
#include <memory>
#include <stdio.h>
#include <thread>
//#include <utility>
//#include <typeinfo>
#include "OSTM.h"

class TM;

class TX {
public:
    /*
     * Constructor
     */
    TX(std::thread::id id);
    /*
     * De-constructor
     */
    ~TX();
    /*
     * Default copy constructor
     */
    TX(const TX& orig);
    /*
     * Delete all map entries associated with the main process
     */
    void ostm_exit();
    /*
     * Clean up all associated values by the thread delete from working_Map_collection map
     */
    void th_exit();
    /*
     * Register OSTM pointer into STM library 
     */
    void _register(OSTM* object);
    /*
     * Register OSTM pointer into STM library 
     */
    OSTM* load(OSTM* object);
    /*
     * Store transactional changes
     */
    void store(OSTM* object);
    /*
     * Commit transactional changes
     */
    bool commit();
    /*
     * Add TX nesting level by one
     */
    void _increase_tx_nesting();
    /*
     * Remove TX nesting level by one
     */
    void _decrease_tx_nesting();
    
    

    
    /*
     * Only for testing ****************************** !!!!!!!!!!!!! ***********************
     */
    int getTest_counter();

    static int test_counter;
    //***********************************************   !!!!!!!!!!!! ***********************

private:

    std::map< int, OSTM* > working_Map_collection;
    std::map< int, OSTM* > rollback_Map_collection;
    
    std::thread::id transaction_Number;
    int _tx_nesting_level;
    
    static std::map<int, OSTM* >main_Process_Map_collection;
    
    /*
     * Should change
     */
    static std::mutex _commit_Lock;
    static std::mutex register_Lock;
    
    

    const std::thread::id _get_tx_number() const;
    
    /*
     * Release object lock
     */
    void _release_object_lock();

};
#endif // _TX_H_



















    /*************************************    OBJECT CHILD BASE POINTER SOLUTION    ***************************/
    
    /*
     * Register method to use for Object type 
     */
//    template<typename T>
//    void _register(T& object) {
//        //std::cout << object << std::endl;
//        std::lock_guard<std::mutex> guard(TX::register_Lock);
//        std::map<int, OSTM*>::iterator main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find(object.Get_Unique_ID());
//        if (main_Process_Map_collection_Iterator == TX::main_Process_Map_collection.end()) {
//
//            OSTM* ptr = &object;
//           // std::cout <<"Original pointer" << ptr << std::endl;
//            TX::main_Process_Map_collection.insert({object.Get_Unique_ID(), ptr});
//            main_Process_Map_collection_Iterator = TX::main_Process_Map_collection.find(object.Get_Unique_ID());
//        }
//
//        OSTM* rollback_Object = object.getBaseCopy(object);
//       // std::cout << "Rollback pointer" << rollback_Object << std::endl;
//        std::map<int, OSTM* >::iterator rollback_Map_collection_Object_Shared_Pointer_Iterator = rollback_Map_collection.find(object.Get_Unique_ID());
//
//        if (rollback_Map_collection_Object_Shared_Pointer_Iterator == rollback_Map_collection.end()) {
//
//            rollback_Map_collection.insert({object.Get_Unique_ID(), rollback_Object});
//        }
//       // std::cout << object.Get_Unique_ID() << std::endl;
//        std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object.Get_Unique_ID());
//        if (working_Map_collection_Object_Shared_Pointer_Iterator == working_Map_collection.end()) {
//           // std::cout << "REGISTER "<< object.Get_Unique_ID() << std::endl;
//           // OSTM* working_Object = object.getBaseCopy(object);
//           // std::cout << "Working pointer " <<working_Object << std::endl;
//            working_Map_collection.insert({object.Get_Unique_ID(), object.getBaseCopy(object)});///working_Object});
//           // working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object.Get_Unique_ID());
//
//        } else {
//            //std::cout << "ALREADY REGISTERED "<< object.Get_Unique_ID() << std::endl;
//            //std::cout << "Object already registered" << std::endl;
//        }
//    }
//
//    /*
//     * Load the T type working_Map_collection object from collection  
//     */
//    template<typename T>
//    T* load(T& object) {
//
//        std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;
//
//        working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object.Get_Unique_ID());
//        if (working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end()) {
//
//            T* obj = dynamic_cast<T*> (working_Map_collection_Object_Shared_Pointer_Iterator->second);
//            return obj->getBaseCopy(obj);
//        }
//    }
//
//    template<typename T>
//    void store(T& object) {
//
//        std::map<int, OSTM*>::iterator main_Process_Map_collection_Iterator;
//
//        std::map< int, OSTM* >::iterator working_Map_collection_Object_Shared_Pointer_Iterator;
//
//        working_Map_collection_Object_Shared_Pointer_Iterator = working_Map_collection.find(object->Get_Unique_ID());
//        if (working_Map_collection_Object_Shared_Pointer_Iterator != working_Map_collection.end()) {
//            main_Process_Map_collection_Iterator = main_Process_Map_collection.find(object->Get_Unique_ID());
//
//            working_Map_collection_Object_Shared_Pointer_Iterator->second = object;
//
//        } else {
//            std::cout << "ERROR ERROR STORE new value" << std::endl;
//        }
//    }
// T* obj = dynamic_cast<T*> (main_Process_Map_collection_Iterator->second);
//((T) working_Map_collection_Object_Shared_Pointer_Iterator->second)->toString();