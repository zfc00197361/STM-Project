/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BOA.cpp
 * Author: zoltan
 * 
 * Created on January 27, 2018, 9:41 PM
 */

#include "BOA.h"

//BOA::BOA() {
//}

BOA::BOA(const BOA& orig) {
}

BOA::~BOA() {
}

BANK* BOA::getBaseCopy(OSTM* object)
{
        BANK* objTO = dynamic_cast<BANK*>(object);
	BANK* obj =  new BOA(objTO,object->Get_Version(),object->Get_Unique_ID()); 
	return obj;
}

void BOA::copy(OSTM* to, OSTM* from){

	BOA* objTO = dynamic_cast<BOA*>(to);
	BOA* objFROM = dynamic_cast<BOA*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());
        
}

BOA* BOA::_cast(OSTM* _object){

    return static_cast<BOA*>(_object);
}

void BOA::toString()
{
   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
	 std::cout << "\nBOA BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void BOA::SetAddress(std::string address) {
    this->address = address;
}

std::string BOA::GetAddress() const {
    return address;
}

void BOA::SetBalance(double balance) {
    this->balance = balance;
}

double BOA::GetBalance() const {
    return balance;
}

void BOA::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int BOA::GetAccountNumber() const {
    return accountNumber;
}

void BOA::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string BOA::GetLastName() const {
    return lastName;
}

void BOA::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string BOA::GetFirstName() const {
    return firstName;
}

void BOA::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string BOA::GetFullname() const {
    return fullname;
}

