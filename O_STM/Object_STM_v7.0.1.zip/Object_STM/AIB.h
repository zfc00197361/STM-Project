/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   AIB.h
 * Author: zoltan
 *
 * Created on January 17, 2018, 8:02 PM
 */

#ifndef AIB_H
#define AIB_H
#include "BANK.h"
#include <string>
#include <memory>
#include <iostream>

class AIB : public BANK {
public:
    
    AIB(): BANK()
    {
        this->accountNumber = 0;
        this->balance = 50;
        this->firstName = "Joe";
        this->lastName = "Blog";
        this->address = "High street, Carlow";
        this->fullname = firstName + " " + lastName;
    
    };
    
    
    
    AIB(int accountNumber, double balance, std::string firstName, std::string lastName, std::string address): BANK()
    {
        this->accountNumber = accountNumber;
        this->balance = balance;
        this->firstName = firstName;
        this->lastName = lastName;
        this->address = address;
        this->fullname = firstName + " " + lastName;
    };
    
    /*
     * OSTM POINTER BASED 
     */
    AIB(BANK* obj, int _version, int _unique_id): BANK(_version, _unique_id)
    {
        
        this->accountNumber = obj->GetAccountNumber();
        this->balance = obj->GetBalance();
        this->firstName = obj->GetFirstName();
        this->lastName = obj->GetLastName();
        this->address = obj->GetAddress();
        this->fullname = obj->GetFirstName() + " " + obj->GetLastName(); 
        
    };
    

    
    AIB(const AIB& orig);
    AIB operator=(const AIB& orig){};
    virtual ~AIB();
    
    /*
     * Implement OSTM virtual methods
     */
    virtual AIB* _cast(OSTM* _object);
    virtual void copy(OSTM* to, OSTM* from);
    virtual BANK* getBaseCopy(OSTM* object);
    virtual void toString();
    
    /*
     * Implement BANK virtual methods
     */
    virtual void SetAddress(std::string address);
    virtual std::string GetAddress() const;
    virtual void SetBalance(double balance);
    virtual double GetBalance() const;
    virtual void SetAccountNumber(int accountNumber);
    virtual int GetAccountNumber() const;
    virtual void SetLastName(std::string lastName);
    virtual std::string GetLastName() const;
    virtual void SetFirstName(std::string firstName);
    virtual std::string GetFirstName() const;
    virtual void SetFullname(std::string fullname);
    virtual std::string GetFullname() const;
    
private:
    std::string fullname;
    std::string firstName;
    std::string lastName;
    int accountNumber;
    double balance;
    std::string address;


};

#endif /* AIB_H */


   // 
   // virtual bool get(OSTM* object);
   // virtual std::string get_class();
    
//    virtual AIB* _get_class(OSTM* object);

    

//    AIB *AIB::GetObject(){
//        AIB *object   =   (AIB*)object;
//        return object;
//    }
///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
///* 
// * File:   AIB.h
// * Author: zoltan
// *
// * Created on January 17, 2018, 8:02 PM
// */
//
//#ifndef AIB_H
//#define AIB_H
//#include "OSTM.h"
//#include <string>
//#include <memory>
//#include <iostream>
//
//class AIB : public OSTM {
//public:
//    
//    AIB(): OSTM()
//    {
//        this->accountNumber = 0;
//        this->balance = 50;
//        this->firstName = "Joe";
//        this->lastName = "Blog";
//        this->address = "High street, Carlow";
//        this->fullname = firstName + " " + lastName;
//    
//    };
//    
//    
//    
//    AIB(int accountNumber, double balance, std::string firstName, std::string lastName, std::string address): OSTM()
//    {
//        this->accountNumber = accountNumber;
//        this->balance = balance;
//        this->firstName = firstName;
//        this->lastName = lastName;
//        this->address = address;
//        this->fullname = firstName + " " + lastName;
//    };
//    
//    AIB(OSTM& obj, int _version, int _unique_id): OSTM(_version, _unique_id)
//    {
//        
////        this->accountNumber = obj->GetAccountNumber();
////        this->balance = obj->GetBalance();
////        this->firstName = obj->GetFirstName();
////        this->lastName = obj->GetLastName();
////        this->address = obj->GetAddress();
////        this->fullname = obj->GetFirstName() + " " + obj->GetLastName(); 
//        this->accountNumber = obj.GetAccountNumber();
//        this->balance = obj.GetBalance();
//        this->firstName = obj.GetFirstName();
//        this->lastName = obj.GetLastName();
//        this->address = obj.GetAddress();
//        this->fullname = obj.GetFirstName() + " " + obj.GetLastName(); 
////        this->accountNumber = obj.accountNumber;
////        this->balance = obj.balance;
////        this->firstName = obj.firstName;
////        this->lastName = obj.lastName;
////        this->address = obj.address;
////        this->fullname = obj.firstName + " " + obj.lastName; 
//    };
//    /*
//     * OSTM POINTER BASED 
//     */
//    AIB(OSTM* obj, int _version, int _unique_id): OSTM(_version, _unique_id)
//    {
//        this->accountNumber = obj->GetAccountNumber();
//        this->balance = obj->_get_double_factory("getbalance");//GetBalance();
//        this->firstName = obj->_get_string_factory("firstname");//GetFirstName();
//        this->lastName = obj->_get_string_factory("lastname");//GetLastName();
//        this->address = obj->_get_string_factory("address");//GetAddress();
//        this->fullname = obj->_get_string_factory("fullname");//GetFirstName() + " " + obj->GetLastName(); 
////        this->accountNumber = obj->accountNumber;
////        this->balance = obj->balance;
////        this->firstName = obj->firstName;
////        this->lastName = obj->lastName;
////        this->address = obj->address;
////        this->fullname = obj->firstName + " " + obj->lastName;
//    };
//    
//
//    
//    AIB(const AIB& orig);
//    AIB operator=(const AIB& orig){};
//    virtual ~AIB();
//    
//    virtual AIB* _cast(OSTM* _object);
//    virtual void copy(OSTM* to, OSTM* from);
//    virtual AIB* getBaseCopy(OSTM& object);
//    virtual AIB* getBaseCopy(OSTM* object);
//    virtual void toString();
//    
//    //USE??
//    virtual int _get_int_factory(std::string _function_);
//    virtual void _set_int_factory(std::string _function_, int value);
//    
//    virtual double _get_double_factory(std::string _function_);
//    virtual void _set_double_factory(std::string _function_, double value);
//    
//    virtual bool _get_bool_factory(std::string _function_);
//    virtual void _set_bool_factory(std::string _function_, bool value);
//    
//    virtual float _get_float_factory(std::string _function_);
//    virtual void _set_float_factory(std::string _function_, float value);
//    
//    virtual std::string _get_string_factory(std::string _function_);
//    virtual void _set_string_factory(std::string _function_, std::string value);
//    
//    virtual char _get_char_factory(std::string _function_);
//    virtual char _set_char_factory(std::string _function_, char value);
//    
//    
//    // DELETE ???
//    virtual void SetAddress(std::string address);
//    virtual std::string GetAddress() const;
//    virtual void SetBalance(double balance);
//    virtual double GetBalance() const;
//    virtual void SetAccountNumber(int accountNumber);
//    virtual int GetAccountNumber() const;
//    virtual void SetLastName(std::string lastName);
//    virtual std::string GetLastName() const;
//    virtual void SetFirstName(std::string firstName);
//    virtual std::string GetFirstName() const;
//    virtual void SetFullname(std::string fullname);
//    virtual std::string GetFullname() const;
//    
//private:
//    std::string fullname;
//    std::string firstName;
//    std::string lastName;
//    int accountNumber;
//    double balance;
//    std::string address;
//
//
//};
//
//#endif /* AIB_H */
//
//
//   // 
//   // virtual bool get(OSTM* object);
//   // virtual std::string get_class();
//    
////    virtual AIB* _get_class(OSTM* object);
//
//    
//
////    AIB *AIB::GetObject(){
////        AIB *object   =   (AIB*)object;
////        return object;
////    }