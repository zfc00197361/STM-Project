/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   BANK.h
 * Author: zoltan
 *
 * Created on January 30, 2018, 5:07 PM
 */

#ifndef BANK_H
#define BANK_H
#include "OSTM.h"

class BANK : public OSTM {

    
public:
    
    BANK(): OSTM(){
        
    };
    
    BANK(int _version, int _unique_id) : OSTM(_version, _unique_id){
        
    };
    
    BANK(const BANK& orig);
    virtual ~BANK();
    
    /*
     * Bank specific virtual 
     */
    virtual void SetAddress(std::string address){};
    virtual std::string GetAddress() const{};
    virtual void SetBalance(double balance){};
    virtual double GetBalance() const{};
    virtual void SetAccountNumber(int accountNumber){};
    virtual int GetAccountNumber() const{};
    virtual void SetLastName(std::string lastName){};
    virtual std::string GetLastName() const{};
    virtual void SetFirstName(std::string firstName){};
    virtual std::string GetFirstName() const{};
    virtual void SetFullname(std::string fullname){};
    virtual std::string GetFullname() const{};
    
private:

};

#endif /* BANK_H */

