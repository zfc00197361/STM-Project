#ifndef TM_H
#define TM_H

#include <thread>
#include <unistd.h>//used for pid_t
#include <mutex>
#include <unordered_map>
#include <utility>
#include <map>
#include "TX.h"



class TM
{
private:
	//std::unordered_map<pid_t, TX>txMap;
        //TX tx;
        std::map<std::thread::id, std::shared_ptr<TX>>txMap;
        void registerTX();//,std::thread::id l_id,std::shared_ptr<Tobj>obj);
        //std::mutex register_Lock;
        std::mutex remove_Lock;
        std::mutex get_Lock;

public:
	TM();

	~TM();

	
	std::shared_ptr<TX>const _get_tx();//,std::thread::id l_id);
        void _clean_tx();
        void _TX_EXIT();
        void print_all();
        //bool validTransaction();

};


#endif // TM_H
