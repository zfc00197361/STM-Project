/* 
 * File:   AIB.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include <math.h>

#include "AIB.h"


AIB::AIB(const AIB& orig) {
}

AIB::~AIB() {
}
/*!
 * \brief getBaseCopy function, make deep copy of the object/pointer and Return a new BANK* type object
 * \param objTO is a BANK type pointer for casting
 * \param obj is a BANK* return type
 */
BANK* AIB::getBaseCopy(OSTM* object)
{

    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new AIB(objTO, object->Get_Version(),object->Get_Unique_ID());
    return obj;
}
/*!
 * \brief copy function, make deep copy of the object/pointer
 * \param objTO is a BANK* type object casted back from OSTM*
 * \param objFROM is a BANK* type object casted back from OSTM*
 */
void AIB::copy(OSTM* to, OSTM* from){

    AIB* objTO = dynamic_cast<AIB*>(to);
    AIB* objFROM = dynamic_cast<AIB*>(from);
    objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
    objTO->Set_Version(objFROM->Get_Version());
    objTO->SetAccountNumber(objFROM->GetAccountNumber());
    objTO->SetBalance(objFROM->GetBalance());
}
/*!
 * \brief _cast, is use to cast bak the OSTM* to the required type
 */
AIB* AIB::_cast(OSTM* _object){
    
    return static_cast<AIB*>(_object);
}
/*!
 *  \brief toString function, displays the object values in formatted way
 */
void AIB::toString()
{
    std::cout << "\nAIB BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void AIB::SetAddress(std::string address) {
    this->address = address;
}

std::string AIB::GetAddress() const {
    return address;
}

void AIB::SetBalance(double balance) {
    this->balance = balance;
}

double AIB::GetBalance() const {
    return balance;
}

void AIB::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int AIB::GetAccountNumber() const {
    return accountNumber;
}

void AIB::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string AIB::GetLastName() const {
    return lastName;
}

void AIB::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string AIB::GetFirstName() const {
    return firstName;
}

void AIB::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string AIB::GetFullname() const {
    return fullname;
}
