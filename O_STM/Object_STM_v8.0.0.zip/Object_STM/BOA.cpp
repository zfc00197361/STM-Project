/* 
 * File:   BOA.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include "BOA.h"


BOA::BOA(const BOA& orig) {
}

BOA::~BOA() {
}
/*!
 * \brief getBaseCopy function, make deep copy of the object/pointer and Return a new BANK* type object
 * \param objTO is a BANK type pointer for casting
 * \param obj is a BANK* return type
 */
BANK* BOA::getBaseCopy(OSTM* object)
{
        BANK* objTO = dynamic_cast<BANK*>(object);
	BANK* obj =  new BOA(objTO,object->Get_Version(),object->Get_Unique_ID()); 
	return obj;
}
/*!
 * \brief copy function, make deep copy of the object/pointer
 * \param objTO is a BANK* type object casted back from OSTM*
 * \param objFROM is a BANK* type object casted back from OSTM*
 */
void BOA::copy(OSTM* to, OSTM* from){

	BOA* objTO = dynamic_cast<BOA*>(to);
	BOA* objFROM = dynamic_cast<BOA*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());
        
}
/*!
 * \brief _cast, is use to cast bak the OSTM* to the required type
 */
BOA* BOA::_cast(OSTM* _object){

    return static_cast<BOA*>(_object);
}
/*!
 *  \brief toString function, displays the object values in formatted way
 */
void BOA::toString()
{
   // std::cout << "\nUnique ID : " << this->GetUniqueID() << "\nInt value : " << this->GetV_int() << "\nDouble value : " << this->GetV_double() << "\nFloat value : " << this->GetV_float() << "\nString value : " << this->GetV_string()  << "\nVersion number : " << this->GetVersion() << "\nLoad Counter : "<< this->GetLoadCounter() << "\nWrite Counter : "<< this->GetWriteCounter() << std::endl;
	 std::cout << "\nBOA BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void BOA::SetAddress(std::string address) {
    this->address = address;
}

std::string BOA::GetAddress() const {
    return address;
}

void BOA::SetBalance(double balance) {
    this->balance = balance;
}

double BOA::GetBalance() const {
    return balance;
}

void BOA::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int BOA::GetAccountNumber() const {
    return accountNumber;
}

void BOA::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string BOA::GetLastName() const {
    return lastName;
}

void BOA::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string BOA::GetFirstName() const {
    return firstName;
}

void BOA::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string BOA::GetFullname() const {
    return fullname;
}

