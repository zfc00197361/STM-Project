
/* 
 * File:   ULSTER.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include "ULSTER.h"

//ULSTER::ULSTER() {
//}

ULSTER::ULSTER(const ULSTER& orig) {
}

ULSTER::~ULSTER() {
}
/*!
 * \brief getBaseCopy function, make deep copy of the object/pointer and Return a new BANK* type object
 * \param objTO is a BANK type pointer for casting
 * \param obj is a BANK* return type
 */
BANK* ULSTER::getBaseCopy(OSTM* object)
{
    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new ULSTER(objTO,object->Get_Version(),object->Get_Unique_ID()); 
    return obj;
}
/*!
 * \brief copy function, make deep copy of the object/pointer
 * \param objTO is a BANK* type object casted back from OSTM*
 * \param objFROM is a BANK* type object casted back from OSTM*
 */
void ULSTER::copy(OSTM* to, OSTM* from){

	ULSTER* objTO = dynamic_cast<ULSTER*>(to);
	ULSTER* objFROM = dynamic_cast<ULSTER*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());

    
}
/*!
 * \brief _cast, is use to cast bak the OSTM* to the required type
 */
ULSTER* ULSTER::_cast(OSTM* _object){

    return static_cast<ULSTER*>(_object);
}
/*!
 *  \brief toString function, displays the object values in formatted way
 */
void ULSTER::toString()
{
   std::cout << "\nULSTER BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void ULSTER::SetAddress(std::string address) {
    this->address = address;
}

std::string ULSTER::GetAddress() const {
    return address;
}

void ULSTER::SetBalance(double balance) {
    this->balance = balance;
}

double ULSTER::GetBalance() const {
    return balance;
}

void ULSTER::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int ULSTER::GetAccountNumber() const {
    return accountNumber;
}

void ULSTER::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string ULSTER::GetLastName() const {
    return lastName;
}

void ULSTER::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string ULSTER::GetFirstName() const {
    return firstName;
}

void ULSTER::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string ULSTER::GetFullname() const {
    return fullname;
}

