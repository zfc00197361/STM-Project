/* 
 * File:   UNBL.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include "UNBL.h"

UNBL::UNBL(const UNBL& orig) {
}

UNBL::~UNBL() {
}
/*!
 * \brief getBaseCopy function, make deep copy of the object/pointer and Return a new BANK* type object
 * \param objTO is a BANK type pointer for casting
 * \param obj is a BANK* return type
 */
BANK* UNBL::getBaseCopy(OSTM* object)
{
    BANK* objTO = dynamic_cast<BANK*>(object);
    BANK* obj =  new UNBL(objTO,object->Get_Version(),object->Get_Unique_ID()); 
    return obj;
}
/*!
 * \brief copy function, make deep copy of the object/pointer
 * \param objTO is a BANK* type object casted back from OSTM*
 * \param objFROM is a BANK* type object casted back from OSTM*
 */
void UNBL::copy(OSTM* to, OSTM* from){

	UNBL* objTO = dynamic_cast<UNBL*>(to);
	UNBL* objFROM = dynamic_cast<UNBL*>(from);
	objTO->Set_Unique_ID(objFROM->Get_Unique_ID());
	objTO->Set_Version(objFROM->Get_Version());
	objTO->SetAccountNumber(objFROM->GetAccountNumber());
	objTO->SetBalance(objFROM->GetBalance());
   
}
/*!
 * \brief _cast, is use to cast bak the OSTM* to the required type
 */
UNBL* UNBL::_cast(OSTM* _object){

    return static_cast<UNBL*>(_object);
}
/*!
 *  \brief toString function, displays the object values in formatted way
 */
void UNBL::toString()
{
   std::cout << "\nUNBL BANK" << "\nUnique ID : " << this->Get_Unique_ID() << "\nInt account : " << this->GetAccountNumber() << "\nDouble value : " << this->GetBalance() << "\nFirst name: " << this->GetFirstName() << "\nLast name : " << this->GetLastName()  << "\nVersion number : " << this->Get_Version() << std::endl;
}

void UNBL::SetAddress(std::string address) {
    this->address = address;
}

std::string UNBL::GetAddress() const {
    return address;
}

void UNBL::SetBalance(double balance) {
    this->balance = balance;
}

double UNBL::GetBalance() const {
    return balance;
}

void UNBL::SetAccountNumber(int accountNumber) {
    this->accountNumber = accountNumber;
}

int UNBL::GetAccountNumber() const {
    return accountNumber;
}

void UNBL::SetLastName(std::string lastName) {
    this->lastName = lastName;
}

std::string UNBL::GetLastName() const {
    return lastName;
}

void UNBL::SetFirstName(std::string firstName) {
    this->firstName = firstName;
}

std::string UNBL::GetFirstName() const {
    return firstName;
}

void UNBL::SetFullname(std::string fullname) {
    this->fullname = fullname;
}

std::string UNBL::GetFullname() const {
    return fullname;
}

