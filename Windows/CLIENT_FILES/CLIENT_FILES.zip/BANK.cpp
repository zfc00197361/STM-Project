/* 
 * File:   BANK.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include "BANK.h"

BANK::BANK(const BANK& orig) {
}

BANK::~BANK() {
}

