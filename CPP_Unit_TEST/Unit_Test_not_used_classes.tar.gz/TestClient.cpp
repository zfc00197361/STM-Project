/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>
#include <string>
#include <list>
#include <cppunit/TestCase.h>
#include <cppunit/TestFixture.h>
#include <cppunit/ui/text/TextTestRunner.h>
#include <cppunit/extensions/HelperMacros.h>
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/TestResult.h>
#include <cppunit/TestResultCollector.h>
#include <cppunit/TestRunner.h>
#include <cppunit/BriefTestProgressListener.h>
#include <cppunit/CompilerOutputter.h>
#include <cppunit/XmlOutputter.h>
#include <netinet/in.h>

#include "client.cpp"

using namespace CppUnit;
using namespace std;


//-----------------------------------------------------------------------------
class TestClient :  public CppUnit::TestFixture  {

CPPUNIT_TEST_SUITE_REGISTRATION(TestClient);
//establish the test suit of TestComplexNumber
CPPUNIT_TEST_SUITE( TestClient);

//add test method testEquals
CPPUNIT_TEST( testEquality );

//add test method testEquals
CPPUNIT_TEST( testAddition );

// finish the process
CPPUNIT_TEST_SUITE_END();
private:
    client *a,*b,*c;
    
public: 

  void setUp()
  {
      a = new client(1);
      b = new client(20);
      c = new client(1);
  }

  void tearDown() 
  {
      delete a;
      delete b;
      delete c;
  }
 
  void testEquality()
  {
      CPPUNIT_ASSERT( a->value == b->value);
 
  }
  
  void testAddition()
  {
    CPPUNIT_ASSERT( a->value + b->value == c->value );
  }
  


};



