
/* 
 * File:   WAREHOUSE.cpp
 * Author: Zoltan Fuzesi
 * IT Carlow : C00197361
 *
 * Created on January 17, 2018, 8:02 PM
 */

#include "WAREHOUSE.h"

WAREHOUSE::WAREHOUSE(const WAREHOUSE& orig) {
}

WAREHOUSE::~WAREHOUSE() {
}

