Linux Shared client, use the lib_o_stm.lib shared library.<br>




